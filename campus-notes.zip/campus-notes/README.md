# campus notes

A Pen created on CodePen.

Original URL: [https://codepen.io/Harshitha-Pathipati/pen/VYmwOML](https://codepen.io/Harshitha-Pathipati/pen/VYmwOML).

